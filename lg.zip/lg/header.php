<!DOCTYPE html>
<html>
<head>
	<title>Self Improvement & Fitness </title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="gym_wscss/animate.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
  <style>
    .wow:first-child {
      visibility: hidden;
    }
    header{
	position:fixed;
	left: 0px;
	top:0px;
	width: 100%;
	z-index: 10;
	background-color: #000000;
	padding:15px 15px;
}
header .container{
	-webkit-display: flex;
	display: flex;
	justify-content: space-between;
	align-items: center;
}

header .logo a{
	font-size: 30px;
	text-decoration: none;
	color:#ffffff;
	font-weight: 700;
}
header .logo a span{
	color:#c11325;
}
header .nav{
	position: fixed;
	background-color: #c11325;
	width: 280px;
	top:0;
	right:0;
	height: 100%;
	z-index: 99;
	padding:100px 0px 15px; 
	-webkit-transform: translateX(100%);
	transform: translateX(100%);
	-webkit-transition: transform .5s ease;
    transition: transform .5s ease;
}
header .nav.open{
	-webkit-transform: translateX(0);
	transform: translateX(0);
}
header .nav ul{
	list-style: none;
	margin:0;
	padding:0px;
}
header .nav ul li{
display: block;
}
header .nav ul li a{
	text-decoration: none;
	font-size: 30px;
	font-weight: 400;
    color:#ffffff;
    display: block;
    position: relative;
    padding:10px 30px;
}
header .nav ul li a.active::before{
	content: '';
	position: absolute;
	left:0px;
	top:0px;
	height: 100%;
	width:100%;
	background-color:#000000;
	opacity:.2;
	-webkit-transition: width .5s ease;
	transition: width .5s ease;
	z-index: -1;
}
header .nav ul li a::before{
	content: '';
	position: absolute;
	left:0px;
	top:0px;
	height: 100%;
	width:0px;
	background-color:#000000;
	opacity:.2;
	-webkit-transition: width .5s ease;
	transition: width .5s ease;
	z-index: -1;
}
header .nav ul li a:hover::before{
	width: 100%;
}
header .ham-burger{
	display: inline-block;
	position: relative;
	z-index: 100;
}
header .ham-burger span{
	height: 3px;
	margin-bottom:8px;
	display: block;
	background-color:#ffffff;
	width:30px;
	-webkit-transition: transform .5s ease;
	transition: transform .5s ease;
}
header .ham-burger span:nth-child(1){
	transform-origin: left top;
}
header .ham-burger span:nth-child(2){
	transform-origin: left bottom;
}

header .ham-burger.active span:nth-child(1){
	-webkit-transform: rotate(45deg) translateY(-6px);
	transform: rotate(45deg) translateY(-6px);
}
header .ham-burger.active span:nth-child(2){
	-webkit-transform: rotate(-45deg) translateY(6px);
	transform: rotate(-45deg) translateY(6px)
}
  </style>
  
</head>
<body>
 
 <!-- Start Header  -->
 <header>
 	 <div class="container">
 	 	<div class="logo">
 	 		 <a href="">Self Improvement & <span> Fitness</span></a>
 	 	</div>
 	 	<a href="javascript:void(0)" class="ham-burger">
 	       <span></span>	
 	       <span></span>
 	 	</a>
 	 	<div class="nav">
 	 		<ul>
 	 			<li><a href="#home">Home</a></li>
 	 			<li><a href="#about">About</a></li>
 	 			<li><a href="../index.php">GMS</a></li>
 	 			<li><a href="../BMI/index.php">BMI</a></li>
 	 			<li><a href="#schedule">Schedule</a></li>
 	 			<li><a href="#price">Price</a></li>
 	 			<li><a href="#contact">Contact</a></li>
 	 		</ul>
 	 	</div>
 	 </div>
 </header>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
	$(document).ready(function(){

      $(".ham-burger, .nav ul li a").click(function(){
       
        $(".nav").toggleClass("open")

        $(".ham-burger").toggleClass("active");
      })      
      $(".accordian-container").click(function(){
      	$(".accordian-container").children(".body").slideUp();
      	$(".accordian-container").removeClass("active")
      	$(".accordian-container").children(".head").children("span").removeClass("fa-angle-down").addClass("fa-angle-up")
      	$(this).children(".body").slideDown();
      	$(this).addClass("active")
      	$(this).children(".head").children("span").removeClass("fa-angle-up").addClass("fa-angle-down")
      })

       $(".nav ul li a, .go-down").click(function(event){
         if(this.hash !== ""){

              event.preventDefault();

              var hash=this.hash; 

              $('html,body').animate({
                scrollTop:$(hash).offset().top
              },800 , function(){
                 window.location.hash=hash;
              });

              // add active class in navigation
              $(".nav ul li a").removeClass("active")
              $(this).addClass("active")
         }
      })
})

</script>
<script src="js/wow.min.js"></script>
<script>
    wow = new WOW(
      {
        animateClass: 'animated',
        offset:       0,
      }
    );
    wow.init();
  </script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
	$(document).ready(function(){

      $(".ham-burger, .nav ul li a").click(function(){
       
        $(".nav").toggleClass("open")

        $(".ham-burger").toggleClass("active");
      })      
      $(".accordian-container").click(function(){
      	$(".accordian-container").children(".body").slideUp();
      	$(".accordian-container").removeClass("active")
      	$(".accordian-container").children(".head").children("span").removeClass("fa-angle-down").addClass("fa-angle-up")
      	$(this).children(".body").slideDown();
      	$(this).addClass("active")
      	$(this).children(".head").children("span").removeClass("fa-angle-up").addClass("fa-angle-down")
      })

       
</script>
<script src="gym_ws/js/wow.min.js"></script>
<script>
    wow = new WOW(
      {
        animateClass: 'animated',
        offset:       0,
      }
    );
    wow.init();
  </script>
</body>
</html>