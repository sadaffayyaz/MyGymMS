<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <link rel="stylesheet" href="style.css">
  <script src="functionality.js"></script>
  <title>BMI Dashboard</title>
</head>

<body>
  <div class="display-4 text-center">BMI Dashboard</div>
  <div class="container" style="margin-top: 40px;">
    <div class="row">
      <div class="col-md-6" style="padding-bottom: 5px;">
        <button type="button" class="btn btn-secondary" style="width: 100%; padding: 10px; "
          onclick="location.reload(true);">Clear</button>
      </div>
      <div class="col-md-6">
        <button type="button" class="btn btn-secondary" style="width: 100%; padding: 10px;"
          onclick="BMIFunction()">Calculate</button>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-sm-4">
        <h4>Weight</h4>
        <form>
          <div class="form-group">
            <table style="width:100%">
              <tr>
                <td><input id="lbsInput" type="number" step="0.0001" class="form-control form-control-lg"
                    placeholder="Pounds...">
                </td>
                <td>lbs</td>
              </tr>
              <tr>
                <td><input id="kgInput" type="number" step="0.0001" class="form-control form-control-lg"
                    placeholder="Kilograms...">
                </td>
                <td>kg</td>
              </tr>
              <tr>
                <td><input id="gmInput" type="number" step="0.0001" class="form-control form-control-lg"
                    placeholder="Grams..."></td>
                <td>gm</td>
              </tr>
              <tr>
                <td><input id="ozInput" type="number" step="0.0001" class="form-control form-control-lg"
                    placeholder="Ounces..."></td>
                <td>oz</td>
              </tr>
            </table>
          </div>
        </form>
      </div>
      <div class="col-sm-4">
        <h4>Height</h4>
        <form>
          <div class="form-group">
            <table style="width:100%">
              <tr>
                <td><input id="cmInput" type="number" step="0.0001" class="form-control form-control-lg"
                    placeholder="Centimeters..."></td>
                <td>cm</td>
              </tr>
              <tr>
                <td><input id="inchInput" type="number" step="0.0001" class="form-control form-control-lg"
                    placeholder="Inches..."></td>
                <td>in</td>
              </tr>
              <tr>
                <td><input id="mInput" type="number" step="0.0001" class="form-control form-control-lg"
                    placeholder="Meters..."></td>
                <td>m</td>
              </tr>
              <tr>
                <td><input id="ftInput" type="number" step="0.0001" class="form-control form-control-lg"
                    placeholder="Feet..."></td>
                <td>ft</td>
              </tr>
            </table>
          </div>
        </form>
      </div>
      <div class="col-sm-4">
        <h4>Health Index</h4>
        <form>
          <div class="form-group">
            <div class="indexcol" id="bmi" style="padding-left: 20px; padding-top: 10px;">
              <p>Body Mass Index...</p>
            </div>
            <div class="indexcol" id="calIn" style="padding-left: 20px; padding-top: 10px;">
              <p>Calorie In...</p>
            </div>
            <div class="indexcol" id="calOut" style="padding-left: 20px; padding-top: 10px;">
              <p>Calorie Out...</p>
            </div>
            <div class="indexcol" id="comment" style="padding-left: 20px; padding-top: 10px;">
              <p>Comment...</p>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
  <div class="footer" style="font-size: 13px;">
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2021 | 
      <a href="https://improv-media-placeholder.netlify.com/" style="text-decoration: none; color: white"><b></b></a>
    </div>
    <!-- Copyright -->
  </div>
</body>

</html>