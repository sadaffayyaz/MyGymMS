<?php
  $serverName = 'localhost';
  $serverUser = 'root';
  $serverPass = '';
  $dbName = 'gms';

  $myCon = new mysqli($serverName,$serverUser,$serverPass,$dbName);
  if($myCon->connect_error)
  {
    echo 'Database not connected';
  }
  if(isset($_POST['submit']))
  {

  $qry ="insert into reg values('1','".$_POST['name']."','".$_POST['email']."', '".$_POST['phone']."','".$_POST['course']."','".$_POST['password']."')";
  if($myCon->query($qry))
  {
    echo 'Data inserted';
  }
  else
  {
    echo 'data not inserted';
  }
}
$myCon = new mysqli($serverName,$serverUser,$serverPass,$dbName);
$res=mysqli_query($myCon,"SELECT * FROM reg;");
echo "<table border='2'><tr><th>Name</th><th>email</th><th>phone</th><th>password</th><th>course</th></tr>";
  while ($row = mysqli_fetch_assoc($res)) {
  echo "<tr><td>";
  echo $row['name'];
  echo "</td><td>";
  echo $row['email'];
  echo "</td><td>";
  echo $row['phone'];
  echo "</td><td>";
  echo $row['password'];
  echo "</td><td>";
  echo $row['course'];
  echo "</td></tr>";

  # code...
}
echo "</table>";
  ?>