<!DOCTYPE html>
<html>
  <head>
    <title>Yoga Application Form</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <style>
      html, body {
      min-height: 100%;
      }
      body, div, form, input, select, textarea, p { 
      padding: 0;
      margin: 0;
      outline: none;
      font-family: Roboto, Arial, sans-serif;
      font-size: 14px;
      color: #666;
      line-height: 22px;
      }
      h1 {
      position: absolute;
      margin: 0;
      font-size: 38px;
      color: #fff;
      z-index: 2;
      }
      .testbox {
      display: flex;
      justify-content: center;
      align-items: center;
      height: inherit;
      padding: 20px;
      }
      form {
      width: 100%;
      padding: 20px;
      border-radius: 6px;
      background: #fff;
      box-shadow: 0 0 25px 0 #892e9b; 
      }
      .banner {
      position: relative;
      height: 210px;
      background-image: url("image/bg.jpg");  
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
      text-align: center;
      }
      .banner::after {
      content: "";
      background-color: rgba(0, 0, 0, 0.3); 
      position: absolute;
      width: 100%;
      height: 100%;
      }
      input, select, textarea {
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 3px;
      }
      input {
      width: calc(100% - 10px);
      padding: 5px;
      }
      input[type="date"] {
      padding: 4px 5px;
      }
      select {
      width: 100%;
      padding: 7px 0;
      background: transparent;
      }
      textarea {
      width: calc(100% - 12px);
      padding: 5px;
      }
      .item:hover p, .item:hover i, .question:hover p, .question label:hover, input:hover::placeholder {
      color: #892e9b;
      }
      .item input:hover, .item select:hover, .item textarea:hover {
      border: 1px solid transparent;
      box-shadow: 0 0 6px 0 #892e9b;
      color: #892e9b;
      }
      .item {
      position: relative;
      margin: 10px 0;
      }
      input[type="date"]::-webkit-inner-spin-button {
      display: none;
      }
      .item i, input[type="date"]::-webkit-calendar-picker-indicator {
      position: absolute;
      font-size: 20px;
      color: #a9a9a9;
      }
      .item i {
      right: 2%;
      top: 30px;
      z-index: 1;
      }
      [type="date"]::-webkit-calendar-picker-indicator {
      right: 1%;
      z-index: 2;
      opacity: 0;
      cursor: pointer;
      }
      input[type=radio], input[type=checkbox]  {
      display: none;
      }
      label.radio {
      position: relative;
      display: inline-block;
      margin: 5px 20px 15px 0;
      cursor: pointer;
      }
      .question span {
      margin-left: 30px;
      }
      label.radio:before {
      content: "";
      position: absolute;
      left: 0;
      width: 17px;
      height: 17px;
      border-radius: 50%;
      border: 2px solid #ccc;
      }
      input[type=radio]:checked + label:before, label.radio:hover:before {
      border: 2px solid #892e9b;
      }
      label.radio:after {
      content: "";
      position: absolute;
      top: 6px;
      left: 5px;
      width: 8px;
      height: 4px;
      border: 3px solid #892e9b;
      border-top: none;
      border-right: none;
      transform: rotate(-45deg);
      opacity: 0;
      }
      input[type=radio]:checked + label:after {
      opacity: 1;
      }
      .btn-block {
      margin-top: 10px;
      text-align: center;
      }
      button {
      width: 150px;
      padding: 10px;
      border: none;
      border-radius: 5px; 
      background: #892e9b;
      font-size: 16px;
      color: #fff;
      cursor: pointer;
      }
      button:hover {
      background: #b52ed1;
      }
      @media (min-width: 568px) {
      .name-item, .city-item {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      }
      .name-item input, .city-item input {
      width: calc(50% - 20px);
      }
      .city-item select {
      width: calc(50% - 8px);
      }
      }
    </style>
  </head>
  <body>
    <div class="testbox">
      <form method="post">
        <div class="banner">
          <h1>Yoga Application Form</h1>
        </div>
        <div class="item">
          <p>Select Course Date</p>
          <input type="date" name="bdate" required/>
          <i class="fas fa-calendar-alt"></i>
        </div>
        <div class="item">
          <p>Name</p>
          <div class="name-item">
            <input type="text" name="fname" placeholder="First" />
            <input type="text" name="lname" placeholder="Last" />
          </div>
        </div>
        <div class="item">
          <p>Email</p>
          <input type="email" name="email"/>
         </div>
        <div class="item">
          <p>Phone</p>
          <input type="text" name="phone" placeholder="### ### ####"/>
        </div>
        <div class="question">
          <p>Gender</p>
          <div class="question-answer">
            <div>
              <input type="radio" value="none" id="radio_1" name="gender"/>
              <label for="radio_1" class="radio"><span>Male</span></label>
            </div>
            <div>
              <input type="radio" value="none" id="radio_2" name="gender"/>
              <label for="radio_2" class="radio"><span>Female</span></label>
            </div>
          </div>
        </div>
          <div class="item">
            <p>Language</p>
            <input type="text" name="language"/>
          </div>
        <div class="item">
          <p>Address</p>
          <input type="text" name="address" placeholder="Street address" required/>
          <input type="text" name="addrss" placeholder="Street address line 2" required/>
          <div class="city-item">
            <input type="text" name="city" placeholder="City" required/>
            <input type="text" name="region" placeholder="Region" required/>
            <input type="text" name="zip" placeholder="Postal / Zip code" required/>
            <select required name="Country">
              <option value="">Country</option>
              <option value="1">Russia</option>
              <option value="2">Germany</option>
              <option value="3">France</option>
              <option value="4">Armenia</option>
              <option value="5">USA</option>
            </select>
          </div>
        </div>
        <div class="item">
          <p>Experience in Yoga</p>
          <textarea rows="3" name="exp"></textarea>
        </div>
        <div class="item">
          <p>Illness (if any)</p>
          <input type="text" name="illness" />
        </div>
        <div class="item">
          <p>Additional Message</p>
          <textarea rows="3" name="addmsg"></textarea>
        </div>
        <div class="btn-block">
          <button type="submit"  name="submt">Send Application</button>
        </div>
      </form>
    </div>

    <?php
  $serverName = 'localhost';
  $serverUser = 'root';
  $serverPass = '';
  $dbName = 'gms';

  $myCon = new mysqli($serverName,$serverUser,$serverPass,$dbName);
  if($myCon->connect_error)
  {
    echo 'Database not connected';
  }
  if(isset($_POST['submt']))
  {

  $qry ="insert into yogaform values('1','".$_POST['bdate']."',
  '".$_POST['fname']."',
  '".$_POST['lname']."',
  '".$_POST['email']."',
   '".$_POST['phone']."',
   '".$_POST['gender']."',
   '".$_POST['language']."',
   '".$_POST['address']."',
   '".$_POST['addrss']."',
   '".$_POST['city']."',
   '".$_POST['zip']."',
   '".$_POST['country']."',
   '".$_POST['exp']."',
   '".$_POST['illness']."',
   '".$_POST['addmsg']."'
   )";
  if($myCon->query($qry))
  {
    echo 'Data inserted';
  }
  else
  {
    echo 'data not inserted';
  }
}
  ?>
  </body>
</html>